const net = require('net');
const sqlite = require('sqlite3').verbose();
const fs = require('fs');
const rc5 = require('rc5');
const xmlbuilder = require('xmlbuilder');
const EncryptionKey = "encryptionsecretkey";
const Encryption = new rc5.default(EncryptionKey);
/*let enc = Encryption.encrypt("this is a test");
console.log(enc + "\n" + Encryption.decrypt(enc));
*/
const SocketServer = new net.Server(), SocketServerPort = 4400;
//Definisco le parole chiave per interagire con il server
const ShowFiles = "MostraListaFiles";
const Search = "Cerca", Delete="Elimina", Download = "Scarica";

const Database = new sqlite.Database("./mappafile.db", (err) => {
  if(err){
    throw err;
  }
  console.log("Connessione al database 'mappafile.db' avvenuta con successo!")
});

SocketServer.listen(SocketServerPort, () => {
  console.log(`Il server è in ascolto sulla porta ${SocketServerPort}!`);
});

SocketServer.on('connection', (socket) => {
  
  socket.on('data', (data) => {
    console.log("Ricevuto : " + data.toString());
    let DataReceived = data.toString();
    switch (DataReceived){
      case ShowFiles:
        Database.all("select Id, NomeFile, Dimensione, Icona from Percorsi", (err, rows) => {
          if(err)socket.write("Error in query");
          else{
            var doc = xmlbuilder.create("root");
            rows.forEach((row) => {
              doc.ele("File")
              .att("Id", row.Id).att("NomeFile", row.NomeFile)
              .att("Dimensione", row.Dimensione)
              //.att("Icona", (row.Icona != null) ? Buffer.from(fs.readFileSync(row.Icona)).toString("base64") : "(null)")
              .up();
            });
            socket.write(doc.toString());
          }
        });
        break;
      default:
        let SplittedData = DataReceived.split("#^#");
        switch (SplittedData[0]) {
          case Search:
            console.log("Richiesta ricerca x " + SplittedData[1]);
            Database.all(`select Id, NomeFile, Dimensione, Icona from Percorsi where NomeFile like ?`, ["%" + SplittedData[1] + "%"], (err, rows) => {
              if(err){
                socket.write("Errore in query:\n"+err.message + "\n");
                console.log(err.stack);
              }
              else{
                if(rows.length == 0){
                  socket.write("No data");
                }else{
                  var doc = xmlbuilder.create("root");
                    rows.forEach((row) => {
                      doc.ele("File")
                      .att("Id", row.Id).att("NomeFile", row.NomeFile)
                      .att("Dimensione", row.Dimensione)
                      .att("Icona", (row.Icona != null) ? Buffer.from(fs.readFileSync(row.Icona)).toString("base64") : "(null)")
                      .up();
                    });
                    socket.write(doc.toString());
                    console.log("just sent\n"+doc.toString());
                }
              }
            });
            break;
          case Delete:
            Database.all("select Percorso, Icona from Percorsi where id=?", [parseInt(SplittedData[1])], (err, rows) => {
              if(err){
                socket.write("Impossibile eliminare il file selezionato: \n" + err.message);
              }else{
                fs.unlink(rows[0].Percorso, (err) => {
                  if(err)socket.write(err.message + "\n\nRilevato al primo unlink");
                  else
                    if(rows[0].Icona != null){
                    	fs.unlink(rows[0].Icona, (err) => {
	                      if(err)socket.write(err.message + "\n\nRilevato al secondo unlink")
	                      Database.run("delete from Percorsi where id=?", [SplittedData[1]], () => {
	                      	socket.write("File eliminato con successo!");
	                      });
	                    });
                    }else{
                    	socket.write("File eliminato con successo!");
                    }
                })
              }
            });
            break;
          case Download:
            Database.all("select Percorso from Percorsi where id=?", [parseInt(SplittedData[1])], (err, rows) => {
              if(err)throw err;
                let FileBuffer = Buffer.from(fs.readFileSync(rows[0].Percorso)).toString("base64") + "*";
                socket.write(FileBuffer);
            });
            break;
          default:
            socket.write("Unknown command");
            break;
        }
        break;
    }
  })

  socket.on('error', (err) => {
    fs.writeFile("Errori.txt", err.message, () => {
      console.log("Si è verificato un errore: L' ho scritto in Errori.txt");
    });
  });
  
  socket.on('end', () => {
    console.log("Disconnessione effettuata");
  });
  
  socket.on('chunk', (chunk) => {
    console.log(chunk);
    socket.write("AsdAsd");
  });
});

const GeneraChiaveRandom = (length = 8) => {
  return Math.random().toString(16).substr(2, length);
};

module.exports = SocketServer;