﻿
namespace Client
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.KillApplicationButton = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.PulsanteImposta = new System.Windows.Forms.Button();
            this.PortInput = new System.Windows.Forms.TextBox();
            this.IpInput = new System.Windows.Forms.TextBox();
            this.PortLabel = new System.Windows.Forms.Label();
            this.IpServerLabel = new System.Windows.Forms.Label();
            this.InputDiRicerca = new System.Windows.Forms.TextBox();
            this.CercaFileButton = new System.Windows.Forms.PictureBox();
            this.FilesDispositionContainer = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CercaFileButton)).BeginInit();
            this.FilesDispositionContainer.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(85)))), ((int)(((byte)(85)))));
            this.panel1.Controls.Add(this.KillApplicationButton);
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(801, 25);
            this.panel1.TabIndex = 0;
            // 
            // KillApplicationButton
            // 
            this.KillApplicationButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.KillApplicationButton.FlatAppearance.BorderSize = 0;
            this.KillApplicationButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.KillApplicationButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KillApplicationButton.Location = new System.Drawing.Point(765, 2);
            this.KillApplicationButton.Name = "KillApplicationButton";
            this.KillApplicationButton.Size = new System.Drawing.Size(33, 20);
            this.KillApplicationButton.TabIndex = 0;
            this.KillApplicationButton.Text = "X";
            this.KillApplicationButton.UseVisualStyleBackColor = false;
            this.KillApplicationButton.Click += new System.EventHandler(this.KillApplicationButton_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.PulsanteImposta);
            this.panel2.Controls.Add(this.PortInput);
            this.panel2.Controls.Add(this.IpInput);
            this.panel2.Controls.Add(this.PortLabel);
            this.panel2.Controls.Add(this.IpServerLabel);
            this.panel2.Location = new System.Drawing.Point(647, 31);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(153, 407);
            this.panel2.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(22, 188);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(108, 31);
            this.button1.TabIndex = 5;
            this.button1.Text = "Disconnettiti";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // PulsanteImposta
            // 
            this.PulsanteImposta.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PulsanteImposta.Location = new System.Drawing.Point(22, 148);
            this.PulsanteImposta.Name = "PulsanteImposta";
            this.PulsanteImposta.Size = new System.Drawing.Size(108, 31);
            this.PulsanteImposta.TabIndex = 4;
            this.PulsanteImposta.Text = "Connettiti";
            this.PulsanteImposta.UseVisualStyleBackColor = true;
            this.PulsanteImposta.Click += new System.EventHandler(this.PulsanteImposta_Click);
            // 
            // PortInput
            // 
            this.PortInput.Location = new System.Drawing.Point(3, 106);
            this.PortInput.Name = "PortInput";
            this.PortInput.Size = new System.Drawing.Size(147, 20);
            this.PortInput.TabIndex = 3;
            // 
            // IpInput
            // 
            this.IpInput.Location = new System.Drawing.Point(3, 51);
            this.IpInput.Name = "IpInput";
            this.IpInput.Size = new System.Drawing.Size(147, 20);
            this.IpInput.TabIndex = 2;
            // 
            // PortLabel
            // 
            this.PortLabel.AutoSize = true;
            this.PortLabel.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PortLabel.Location = new System.Drawing.Point(51, 82);
            this.PortLabel.Name = "PortLabel";
            this.PortLabel.Size = new System.Drawing.Size(52, 21);
            this.PortLabel.TabIndex = 1;
            this.PortLabel.Text = "Porta";
            // 
            // IpServerLabel
            // 
            this.IpServerLabel.AutoSize = true;
            this.IpServerLabel.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IpServerLabel.Location = new System.Drawing.Point(36, 27);
            this.IpServerLabel.Name = "IpServerLabel";
            this.IpServerLabel.Size = new System.Drawing.Size(79, 21);
            this.IpServerLabel.TabIndex = 0;
            this.IpServerLabel.Text = "IP server";
            // 
            // InputDiRicerca
            // 
            this.InputDiRicerca.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InputDiRicerca.Location = new System.Drawing.Point(12, 31);
            this.InputDiRicerca.Multiline = true;
            this.InputDiRicerca.Name = "InputDiRicerca";
            this.InputDiRicerca.Size = new System.Drawing.Size(590, 27);
            this.InputDiRicerca.TabIndex = 3;
            // 
            // CercaFileButton
            // 
            this.CercaFileButton.BackColor = System.Drawing.Color.White;
            this.CercaFileButton.Image = ((System.Drawing.Image)(resources.GetObject("CercaFileButton.Image")));
            this.CercaFileButton.Location = new System.Drawing.Point(608, 31);
            this.CercaFileButton.Name = "CercaFileButton";
            this.CercaFileButton.Size = new System.Drawing.Size(33, 27);
            this.CercaFileButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.CercaFileButton.TabIndex = 4;
            this.CercaFileButton.TabStop = false;
            this.CercaFileButton.Click += new System.EventHandler(this.CercaFileButton_Click);
            // 
            // FilesDispositionContainer
            // 
            this.FilesDispositionContainer.AutoScroll = true;
            this.FilesDispositionContainer.Controls.Add(this.panel5);
            this.FilesDispositionContainer.Location = new System.Drawing.Point(12, 82);
            this.FilesDispositionContainer.Name = "FilesDispositionContainer";
            this.FilesDispositionContainer.Size = new System.Drawing.Size(629, 356);
            this.FilesDispositionContainer.TabIndex = 5;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.pictureBox2);
            this.panel5.Location = new System.Drawing.Point(12, 166);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(0, 0);
            this.panel5.TabIndex = 2;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(28, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(96, 96);
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.FilesDispositionContainer);
            this.Controls.Add(this.CercaFileButton);
            this.Controls.Add(this.InputDiRicerca);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CercaFileButton)).EndInit();
            this.FilesDispositionContainer.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label PortLabel;
        private System.Windows.Forms.Label IpServerLabel;
        private System.Windows.Forms.TextBox PortInput;
        private System.Windows.Forms.TextBox IpInput;
        private System.Windows.Forms.Button PulsanteImposta;
        private System.Windows.Forms.Button KillApplicationButton;
        private System.Windows.Forms.TextBox InputDiRicerca;
        private System.Windows.Forms.PictureBox CercaFileButton;
        private System.Windows.Forms.Panel FilesDispositionContainer;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button1;
    }
}

