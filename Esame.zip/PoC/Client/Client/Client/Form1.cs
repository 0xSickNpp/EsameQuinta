﻿using System;
using System.Net;
using System.Windows.Forms;
using System.IO;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
namespace Client
{
    public partial class Form1 : Form
    {
        private int y0 = 12, yincremental = 167;
        private int x0 = 31, x1 = 248, x2 = 457;
        private int xicon = 25, xiconlen = 80;

        private ServerConnection Server = null;
        private const string ShowListKey = "MostraListaFiles";

        private List<Panel> GuiPackedElements = new List<Panel>();

        public Form1()
        {
            InitializeComponent();
        }

        #region ComandiForms
        private void KillApplicationButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void PulsanteImposta_Click(object sender, EventArgs e)
        {
            string Ip = this.IpInput.Text;
            IPAddress HostIp = null;
            if(IPAddress.TryParse(Ip, out HostIp) == false)
            {
                MessageBox.Show("Indirizzo ip non valido!", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int Porta = 0;
            try
            {
                Porta = int.Parse(this.PortInput.Text);
            }
            catch
            {
                MessageBox.Show("Numero porta non valido!", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                IPAddress ServerIpAddr = IPAddress.Parse(Ip);
                this.Server = new ServerConnection(ServerIpAddr, Porta);
                if(this.Server.VerifyConnectivity() == false)
                {
                    this.Server = null;
                }
                MessageBox.Show("Connessione al server avvenuta con successo!", "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch(Exception ex)
            {
                this.Server = null;
                MessageBox.Show(ex.Message, "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Server.CloseConnectionToServer();
            MessageBox.Show("Connessione con il server chiusa con successo", "Ok", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private string Truncate(string value, int maxLength)
        {
            if (string.IsNullOrEmpty(value)) return value;
            return value.Length <= maxLength ? value : value.Substring(0, maxLength);
        }

        private void CercaFileButton_Click(object sender, EventArgs e)
        {
            try
            {
                string QuerySearchString = this.InputDiRicerca.Text;

                string Response = this.Server.QueryServer((String.IsNullOrEmpty(QuerySearchString) ? ShowListKey : "Cerca#^#" + QuerySearchString));

                Response = this.Truncate(Response, Response.LastIndexOf('>') + 1);
                var ParsedResponse = XDocument.Parse(Response);

                var c = ParsedResponse.Root;

                List<FileDetails> Fdts = new List<FileDetails>();

                foreach (XElement x in c.Elements())
                {
                    FileDetails f = new FileDetails();
                    f.id = int.Parse(x.Attribute("Id").Value);
                    f.name = x.Attribute("NomeFile").Value;
                    f.size = x.Attribute("Dimensione").Value;
                    //f.icon = x.Attribute("Icona").Value;
                    Fdts.Add(f);
                }
                foreach (Panel pp in this.GuiPackedElements)
                {
                    this.FilesDispositionContainer.Controls.Remove(pp);
                }
                this.GuiPackedElements.Clear();
                PackFilesToGUI(Fdts);
            }
            catch
            {

            }
        }

        private void DownloadFile(object sender, EventArgs e)
        {
            string fileid = ((Button)sender).Tag.ToString();
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            sfd.Title = "Scegli la destinazione del file";
            if(sfd.ShowDialog() == DialogResult.OK)
            {
                string Query = "Scarica#^#" + fileid;
                string Response = this.Server.QueryServer(Query);
                string filename = sfd.FileName;
                Response = this.Truncate(Response, Response.IndexOf("*"));
                File.WriteAllBytes(filename, Convert.FromBase64String(Response));
                if(MessageBox.Show("Download completato! Vuoi aprire il file appena scaricato?", "Ok", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    try
                    {
                        Process downloadedfile = new Process();
                        downloadedfile.StartInfo.FileName = filename;
                        downloadedfile.Start();
                    }
                    catch
                    {

                    }
                }
            }

        }

        private void DeleteFile(object sender, EventArgs e)
        {
            string fileid = ((PictureBox)sender).Tag.ToString();
            string Query = "Elimina#^#" + fileid;
            string Response = this.Server.QueryServer(Query);
            MessageBox.Show(Response, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        #endregion

        #region functions


        private void PackFilesToGUI(List<FileDetails> fd)
        {
            y0 = 12;
            
            int colcounter = 1;
            fd.ForEach((f) =>
            {
                if (colcounter == 4)
                {
                    colcounter = 1;
                    y0 += yincremental;
                }
                int xtouse = 0;
                switch (colcounter)
                {
                    case 1:
                        xtouse = x0;
                        break;
                    case 2:
                        xtouse = x1;
                        break;
                    case 3:
                        xtouse = x2;
                        break;
                    default:
                        xtouse = x0;
                        break;
                }
                Panel p = new Panel();
                p.Location = new Point(xtouse, y0);
                p.BorderStyle = BorderStyle.FixedSingle;
                p.Size = new Size(133, 157);
                //creazione degli elementi nel pannello
                PictureBox pctbx = new PictureBox();
                //byte[] pic = Convert.FromBase64String(f.icon);
                pctbx.SizeMode = PictureBoxSizeMode.StretchImage;
                pctbx.BorderStyle = BorderStyle.FixedSingle;
                pctbx.Size = new Size(xiconlen, xiconlen);
                pctbx.Location = new Point(xicon, 0);
                pctbx.Tag = f.id;
                pctbx.Click += new EventHandler(this.DeleteFile);
                p.Controls.Add(pctbx);

                Label l = new Label();
                l.AutoSize = true;
                l.TextAlign = ContentAlignment.MiddleCenter;
                l.Text = f.name + "\nDimensione : " + f.size;
                l.Location = new Point(10, p.Height/2);
                l.Font = new Font("Franklin Gothic", 9);
                p.Controls.Add(l);
                //CREA IL BOTTONE PER IL DOWNLOAD
                Button bdw = new Button();
                bdw.Text = "Download";
                bdw.Size = new Size(71, 23);
                bdw.Location = new Point(30, p.Height - 30);
                bdw.Tag = f.id;
                bdw.Click += new EventHandler(this.DownloadFile);
                p.Controls.Add(bdw);
                //fine
                this.FilesDispositionContainer.Controls.Add(p);
                this.GuiPackedElements.Add(p);
                colcounter++;
            });
        }

        #endregion

        public struct FileDetails
        {
            public int    id   { get; set; }
            public string name { get; set; }
            public string size { get; set; }
            public string icon { get; set; }
        }
    }
}
