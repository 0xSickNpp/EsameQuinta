﻿using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;
using System.Collections.Generic;

namespace Client
{
    class ServerConnection
    {
        private Socket Client = null;

        public ServerConnection(IPAddress ServerAddress, int ServerPort)
        {
            try
            {
                IPEndPoint ServerEP = new IPEndPoint(ServerAddress, ServerPort);
                this.Client = new Socket(ServerAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                this.Client.Connect(ServerEP);
            }
            catch
            {
                this.Client = null;
                MessageBox.Show("Il server remoto potrebbe essere offline oppure potresti non essere connesso" +
                    "ad internet.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public bool VerifyConnectivity()
        {
            return (this.Client == null) ? false : true;
        }

        public string QueryServer(string Query)
        {
            try
            {
                if (this.Client == null)
                {
                    MessageBox.Show("Non è stata inizializzata alcuna connessione.", "Errore", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return null;
                }
                this.Client.Send(Encoding.ASCII.GetBytes(Query));
                List<byte> ResponseBuffer = new List<byte>();
                do
                {
                    byte[] ResponseBytes = new byte[1024];
                    this.Client.Receive(ResponseBytes, ResponseBytes.Length, SocketFlags.None);
                    foreach (byte b in ResponseBytes)
                    {
                        ResponseBuffer.Add(b);
                    }
                } while (this.Client.Available > 0);
                return Encoding.ASCII.GetString(ResponseBuffer.ToArray());
            }
            catch
            {
                return null;
            }


        }

        public void CloseConnectionToServer()
        {
            this.Client.Shutdown(SocketShutdown.Both);
            this.Client.Close();
        }
    }
}
